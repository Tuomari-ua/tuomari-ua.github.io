---
layout: page-nontoc
category: index
title: Чари
---
## Загальні правила створення чарів

* [Що таке чари?](/spellcasting/what_is_a_spell.html)
* [Створення чарів](/spellcasting/casting_a_spell.html)

## Списки чарів за типами

* [Чари за рівнями](/spellcasting/spell_indexes/spells_by_level.html)
* [Чари за назвою](/spellcasting/spell_indexes/spells_by_name.html)
* [Чари за школами](/spellcasting/spell_indexes/spells_by_school.html)

## Списки чарів за класами

* [Бард](/spellcasting/spell_lists/bard_spells.html)
* [Друїд](/spellcasting/spell_lists/druid_spells.html)
* [Заклинач](/spellcasting/spell_lists/sorcerer_spells.html)
* [Клірик](/spellcasting/spell_lists/cleric_spells.html)
* [Маг](/spellcasting/spell_lists/wizard_spells.html)
* [Паладин](/spellcasting/spell_lists/paladin_spells.html)
* [Рейнджер](/spellcasting/spell_lists/ranger_spells.html)
* [Чаклун](/spellcasting/spell_lists/warlock_spells.html)
