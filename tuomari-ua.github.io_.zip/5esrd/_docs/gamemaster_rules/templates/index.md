# Templates

* [Halfdragon Template](/gamemaster_rules/templates/halfdragon_template/)