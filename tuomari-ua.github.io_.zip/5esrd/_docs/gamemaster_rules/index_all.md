---
layout: page-nontoc
category: index
title: Правила майстра
---

## Загальні правила

* [Хвороби](/gamemaster_rules/diseases.html)
* [Легендарні істоти](/gamemaster_rules/legendary_creatures.html)
* [Безумство](/gamemaster_rules/madness.html)
* [Магічні предмети](/gamemaster_rules/magic_items.html)
* [Mонстри](/gamemaster_rules/monsters.html)
* [Неігрові персонажі](/gamemaster_rules/nonplayer_characters.html)
* [Предмети](/gamemaster_rules/objects.html)
* [Отрути](/gamemaster_rules/poisons.html)
* [Розумні магічні предмети](/gamemaster_rules/sentient_magical_items.html)
* [Пастки](/gamemaster_rules/traps.html)

## Списки магічних предметів

* [Предмети за назвою](/gamemaster_rules/magic_item_indexes/items_by_name.html)
* [Предмети за типом](/gamemaster_rules/magic_item_indexes/items_by_type.html)

## Списки монстрів

* [Монстри за назвами](/gamemaster_rules/monster_indexes/monsters_by_name.html)
* [Монстри за типом](/gamemaster_rules/monster_indexes/monsters_by_type.html)
* [Монстри за класом небезпеки](/gamemaster_rules/monster_indexes/monsters_by_cr.html)

## Шаблони

* [Шаблон напівдракона](/gamemaster_rules/templates/halfdragon_template.html)
