---
layout: page-nontoc
category: index
title: Правила
---
## Загальні правила

* [Бонус досвіду](/rules/proficiency_bonus.html)
* [Натхнення](/rules/inspiration.html)
* [Перевага та перешкода](/rules/advantage_and_disadvantage.html)
* [Підвищення рівня](/rules/leveling_up.html)
* [Мультиклас](/rules/multiclassing.html)
* [Уміння](/rules/feats.html)
* [Стани](/rules/conditions.html)
* [Витрати](/rules/expenses.html)

## Здібності

* [Сила](/rules/abilities/strength.html)
* [Спритність](/rules/abilities/dexterity.html)
* [Статура](/rules/abilities/constitution.html)
* [Інтелект](/rules/abilities/intelligence.html)
* [Мудрість](/rules/abilities/wisdom.html)
* [Харизма](/rules/abilities/charisma.html)
* [Перевірки здібностей](/rules/abilities/ability_checks.html)
* [Значення здібностей](/rules/abilities/ability_scores.html)
* [Рятівні кидки](/rules/abilities/saving_throws.html)
