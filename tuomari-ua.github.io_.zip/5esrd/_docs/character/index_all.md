---
layout: page-nontoc
category: index
title: Персонаж
---
## Загальні відомості
* [Світогляд](/character/alignment.html)
* [Передісторія](/character/backgrounds.html)
* [Фантастично-історичні пантеони](/character/fantasy-historical_pantheons.html)
* [Мови](/character/languages.html)

## Класи

* [Бард](/character/classes/bard.html)
* [Боєць](/character/classes/fighter.html)
* [Варвар](/character/classes/barbarian.html)
* [Друїд](/character/classes/druid.html)
* [Заклинач](/character/classes/sorcerer.html)
* [Клірик](/character/classes/cleric.html)
* [Маг](/character/classes/wizard.html)
* [Монах](/character/classes/monk.html)
* [Паладин](/character/classes/paladin.html)
* [Пройдисвіт](/character/classes/rogue.html)
* [Рейнджер](/character/classes/ranger.html)
* [Чаклун](/character/classes/warlock.html)


## Раси

* [Людина](/character/races/human.html)
* [Гном](/character/races/gnome.html)
* [Дворф](/character/races/dwarf.html)
* [Ельф](/character/races/elf.html)
* [Напівельф](/character/races/half-elf.html)
* [Напіврослик](/character/races/halfling.html)
* [Напіворк](/character/races/half-orc.html)
* [Тифлінґ](/character/races/tiefling.html)
* [Драконороджений](/character/races/dragonborn.html)
