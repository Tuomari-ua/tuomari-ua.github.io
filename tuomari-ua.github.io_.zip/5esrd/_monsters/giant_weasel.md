---
layout: page-nontoc
category: monsters
title: Giant Weasel
type: Beast
tag: .125
---
_Medium beast, unaligned_

**Armor Class** 13    
**Hit Points** 9 (2d8)    
**Speed** 40 ft. 

| STR     | DEX     | CON     | INT     | WIS     | CHA     |
|---------|---------|---------|---------|---------|---------|
| 11 (+0) | 16 (+3) | 10 (+0) | 4 (−3)  | 12 (+1) | 5 (−3)  |  

**Skills** Perception +3, Stealth +5    
**Senses** darkvision 60 ft., passive Perception 13    
**Languages** --    
**Challenge** 1/8 (25 XP) 

**Keen Hearing and Smell.** The weasel has advantage on Wisdom (Perception) checks that rely on hearing or smell. 

### Actions    
**Bite.** _Melee Weapon Attack:_ +5 to hit, reach 5 ft., one target. _Hit:_ 5 (1d4 + 3) piercing damage. 