---
layout: page-nontoc
category: monsters
title: Mule
type: Beast
tag: .125
---
_Medium beast, unaligned_

**Armor Class** 10    
**Hit Points** 11 (2d8 + 2)    
**Speed** 40 ft. 

| STR     | DEX     | CON     | INT     | WIS     | CHA     |
|---------|---------|---------|---------|---------|---------|
| 14 (+2) | 10 (+0) | 13 (+1) | 2 (−4)  | 10 (+0) | 5 (−3)  |  

**Senses** passive Perception 10    
**Languages** --    
**Challenge** 1/8 (25 XP) 

**Beast of Burden.** The mule is considered to be a Large animal for the purpose of determining its carrying capacity.    
**Sure-Footed.** The mule has advantage on Strength and Dexterity saving throws made against effects that would knock it prone. 

### Actions 
**Hooves.** _Melee Weapon Attack:_ +2 to hit, reach 5 ft., one target. _Hit:_ 4 (1d4 + 2) bludgeoning damage. 