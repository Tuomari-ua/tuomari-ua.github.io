---
layout: page-nontoc
category: monsters
title: Frost Giant
type: Giant
tag: 8
---
_Huge giant, neutral evil_

**Armor Class** 15 (patchwork armor)    
**Hit Points** 138 (12d12 + 60)    
**Speed** 40 ft. 

| STR     | DEX     | CON     | INT     | WIS     | CHA     |
|---------|---------|---------|---------|---------|---------|
| 23 (+6) | 9 (−1)  | 21 (+5) | 9 (−1)  | 10 (+0) | 12 (+1) |

**Saving Throws** Con +8, Wis +3, Cha +4    
**Skills** Athletics +9, Perception +3    
**Damage Immunities** cold    
**Senses** passive Perception 13    
**Languages** Giant    
**Challenge** 8 (3,900 XP) 

### Actions 
**Multiattack.** The giant makes two greataxe attacks.    
**Greataxe.** _Melee Weapon Attack:_ +9 to hit, reach 10 ft., one target. _Hit:_ 25 (3d12 + 6) slashing damage.    
**Rock.** _Ranged Weapon Attack:_ +9 to hit, range 60/240 ft., one target. _Hit:_ 28 (4d10 + 6) bludgeoning damage.