---
category: items
layout: page
name: Dragon Slayer
tag: weapon
title: Dragon Slayer 
---
_Weapon (any sword), rare_ 

You gain a +1 bonus to attack and damage rolls made with this magic weapon.

When you hit a dragon with this weapon, the dragon takes an extra 3d6 damage of the weapon's type. For the purpose of this weapon, "dragon" refers to any creature with the dragon type, including dragon turtles and wyverns. 