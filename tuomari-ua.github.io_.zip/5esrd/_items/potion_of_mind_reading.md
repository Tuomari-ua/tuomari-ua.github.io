---
category: items
layout: page
name: Potion of Mind Reading
tag: potion
title: Potion of Mind Reading 
---
_Potion, rare_ 

When you drink this potion, you gain the effect of the **_detect thoughts_** spell (save DC 13). The potion's dense, purple liquid has an ovoid cloud of pink floating in it. 