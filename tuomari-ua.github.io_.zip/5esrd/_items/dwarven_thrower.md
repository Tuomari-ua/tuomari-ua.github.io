---
category: items
layout: page
name: Dwarven Thrower
tag: weapon
title: Dwarven Thrower 
---
_Weapon (warhammer), very rare (requires attunement by a dwarf)_ 

You gain a +3 bonus to attack and damage rolls made with this magic weapon. It has the thrown property with a normal range of 20 feet and a long range of 60 feet. When you hit with a ranged attack using this weapon, it deals an extra 1d8 damage or, if the target is a giant, 2d8 damage. Immediately after the attack, the weapon flies back to your hand.