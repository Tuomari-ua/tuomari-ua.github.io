---
category: items
layout: page
name: Periapt of Health
tag: item
title: Periapt of Health 
---
_Wondrous item, uncommon_ 

You are immune to contracting any disease while you wear this pendant. If you are already infected with a disease, the effects of the disease are suppressed you while you wear the pendant. 