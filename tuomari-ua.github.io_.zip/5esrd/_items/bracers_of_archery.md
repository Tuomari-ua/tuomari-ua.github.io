---
category: items
layout: page
name: Bracers of Archery
tag: item
title: Bracers of Archery 
---
_Wondrous item, uncommon (requires attunement)_ 

While wearing these bracers, you have proficiency with the longbow and shortbow, and you gain a +2 bonus to damage rolls on ranged attacks made with such weapons. 