---
category: items
layout: page
name: Armor, +1, +2, or +3
tag: armor
title: Armor, +1, +2, or +3 
---
_Armor (light, medium, or heavy), rare (+1), very rare (+2), or legendary (+3)_ 

You have a bonus to AC while wearing this armor. The bonus is determined by its rarity. 