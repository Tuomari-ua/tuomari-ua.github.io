---
category: items
layout: page
name: Ring of Jumping
tag: ring
title: Ring of Jumping 
---
_Ring, uncommon (requires attunement)_ 

While wearing this ring, you can cast the jump spell from it as a bonus action at will, but can target only yourself when you do so. 