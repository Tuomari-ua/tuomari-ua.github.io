---
category: items
layout: page
name: Mithral Armor
tag: armor
title: Mithral Armor 
---
_Armor (medium or heavy, but not hide), uncommon_ 

Mithral is a light, flexible metal. A mithral chain shirt or breastplate can be worn under normal clothes. If the armor normally imposes disadvantage on Dexterity (Stealth) checks or has a Strength requirement, the mithral version of the armor doesn't.