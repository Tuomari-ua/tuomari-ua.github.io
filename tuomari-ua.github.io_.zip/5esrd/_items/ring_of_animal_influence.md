---
category: items
layout: page
name: Ring of Animal Influence
tag: ring
title: Ring of Animal Influence 
---
_Ring, rare_ 

This ring has 3 charges, and it regains 1d3 expended charges daily at dawn. While wearing the ring, you can use an action to expend 1 of its charges to cast one of the following spells: 

* **_Animal friendship_** (save DC 13)
* **_Fear_** (save DC 13), targeting only beasts that have an Intelligence of 3 or lower 
* **_Speak with animals_** 