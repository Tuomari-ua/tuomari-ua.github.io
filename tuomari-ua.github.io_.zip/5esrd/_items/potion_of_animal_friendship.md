---
category: items
layout: page
name: Potion of Animal Friendship
tag: potion
title: Potion of Animal Friendship 
---
_Potion, uncommon_ 

When you drink this potion, you can cast the **_animal friendship_** spell (save DC 13) for 1 hour at will. Agitating this muddy liquid brings little bits into view: a fish scale, a hummingbird tongue, a cat claw, or a squirrel hair. 