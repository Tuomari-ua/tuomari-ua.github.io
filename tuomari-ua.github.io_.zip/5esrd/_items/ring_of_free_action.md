---
category: items
layout: page
name: Ring of Free Action
tag: ring
title: Ring of Free Action 
---
_Ring, rare (requires attunement)_ 

While you wear this ring, difficult terrain doesn't cost you extra movement. In addition, magic can neither reduce your speed nor cause you to be paralyzed or restrained. 