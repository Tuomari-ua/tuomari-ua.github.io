---
category: items
layout: page
name: Cloak of Protection
tag: item
title: Cloak of Protection 
---
_Wondrous item, uncommon (requires attunement)_ 

You gain a +1 bonus to AC and saving throws while you wear this cloak. 