---
category: items
layout: page
name: Ring of Feather Falling
tag: ring
title: Ring of Feather Falling 
---
_Ring, rare (requires attunement)_ 

When you fall while wearing this ring, you descend 60 feet per round and take no damage from falling. 