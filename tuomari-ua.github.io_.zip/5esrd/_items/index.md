---
category: items
layout: page-nontoc
title: Magic Items Indexes

* [Magic Items by Type](/gamemaster_rules/magic_item_indexes/items_by_type/)