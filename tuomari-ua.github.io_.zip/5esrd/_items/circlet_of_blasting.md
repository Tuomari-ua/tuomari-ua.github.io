---
category: items
layout: page
name: Circlet of Blasting
tag: item
title: Circlet of Blasting 
---
_Wondrous item, uncommon_ 

While wearing this circlet, you can use an action to cast the **_scorching ray_** spell with it. When you make the spell's attacks, you do so with an attack bonus of +5. The circlet can't be used this way again until the next dawn. 