---
category: items
layout: page
name: Eyes of the Eagle
tag: item
title: Eyes of the Eagle 
---
_Wondrous item, uncommon (requires attunement)_ 

These crystal lenses fit over the eyes. While wearing them, you have advantage on Wisdom (Perception) checks that rely on sight. In conditions of clear visibility, you can make out details of even extremely distant creatures and objects as small as 2 feet across.