---
category: items
layout: page
name: Manual of Bodily Health
tag: item
title: Manual of Bodily Health 
---
_Wondrous item, very rare_ 

This book contains health and diet tips, and its words are charged with magic. If you spend 48 hours over a period of 6 days or fewer studying the book's contents and practicing its guidelines, your Constitution score increases by 2, as does your maximum for that score. The manual then loses its magic, but regains it in a century. 