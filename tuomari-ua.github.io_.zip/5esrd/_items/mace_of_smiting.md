---
category: items
layout: page
name: Mace of Smiting
tag: weapon
title: Mace of Smiting 
---
_Weapon (mace), rare_ 

You gain a +1 bonus to attack and damage rolls made with this magic weapon. The bonus increases to +3 when you use the mace to attack a construct.

When you roll a 20 on an attack roll made with this weapon, the target takes an extra 2d6 bludgeoning damage, or 4d6 bludgeoning damage if it's a construct. If a construct has 25 hit points or fewer after taking this damage, it is destroyed. 