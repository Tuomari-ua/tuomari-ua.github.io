---
category: items
layout: page
name: Bracers of Defense
tag: item
title: Bracers of Defense 
---
_Wondrous item, rare (requires attunement)_ 

While wearing these bracers, you gain a +2 bonus to AC if you are wearing no armor and using no shield. 