---
category: items
layout: page
name: Ring of Water Walking
tag: ring
title: Ring of Water Walking 
---
_Ring, uncommon_ 

While wearing this ring, you can stand on and move across any liquid surface as if it were solid ground. 