---
category: items
layout: page
name: Hat of Disguise
tag: item
title: Hat of Disguise 
---
_Wondrous item, uncommon (requires attunement)_ 

While wearing this hat, you can use an action to cast the **_disguise self_** spell from it at will. The spell ends if the hat is removed. 