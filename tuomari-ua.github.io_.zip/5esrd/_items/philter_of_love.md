---
category: items
layout: page
name: Philter of Love
tag: potion
title: Philter of Love 
---
_Potion, uncommon_ 

The next time you see a creature within 10 minutes after drinking this philter, you become charmed by that creature for 1 hour. If the creature is of a species and gender you are normally attracted to, you regard it as your true love while you are charmed. This potion's rose-hued, effervescent liquid contains one easy-to-miss bubble shaped like a heart. 