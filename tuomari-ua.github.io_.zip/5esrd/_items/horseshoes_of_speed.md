---
category: items
layout: page
name: Horseshoes of Speed
tag: item
title: Horseshoes of Speed 
---
_Wondrous item, rare_ 

These iron horseshoes come in a set of four. While all four shoes are affixed to the hooves of a horse or similar creature, they increase the creature's walking speed by 30 feet.