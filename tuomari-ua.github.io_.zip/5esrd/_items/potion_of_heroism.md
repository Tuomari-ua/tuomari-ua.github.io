---
category: items
layout: page
name: Potion of Heroism
tag: potion
title: Potion of Heroism 
---
_Potion, rare_ 

For 1 hour after drinking it, you gain 10 temporary hit points that last for 1 hour. For the same duration, you are under the effect of the **_bless_** spell (no concentration required). This blue potion bubbles and steams as if boiling. 