---
category: items
layout: page
name: Boots of Levitation
tag: item
title: Boots of Levitation 
---
_Wondrous item, rare (requires attunement)_ 

While you wear these boots, you can use an action to cast the **_levitate_** spell on yourself at will. 