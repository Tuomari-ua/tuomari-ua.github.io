---
category: items
layout: page
name: Boots of Speed
tag: item
title: Boots of Speed 
---
_Wondrous item, rare (requires attunement)_ 

While you wear these boots, you can use a bonus action and click the boots' heels together. If you do, the boots double your walking speed, and any creature that makes an opportunity attack against you has disadvantage on the attack roll. If you click your heels together again, you end the effect.

When the boots' property has been used for a total of 10 minutes, the magic ceases to function until you finish a long rest. 