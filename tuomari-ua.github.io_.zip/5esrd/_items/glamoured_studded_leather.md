---
category: items
layout: page
name: Glamoured Studded Leather
tag: armor
title: Glamoured Studded Leather 
---
_Armor (studded leather), rare_ 

While wearing this armor, you gain a +1 bonus to AC. You can also use a bonus action to speak the armor's command word and cause the armor to assume the appearance of a normal set of clothing or some other kind of armor. You decide what it looks like, including color, style, and accessories, but the armor retains its normal bulk and weight. The illusory appearance lasts until you use this property again or remove the armor. 