---
category: items
layout: page
name: Boots of Elvenkind
tag: item
title: Boots of Elvenkind 
---
_Wondrous item, uncommon_ 

While you wear these boots, your steps make no sound, regardless of the surface you are moving across. You also have advantage on Dexterity (Stealth) checks that rely on moving silently. 