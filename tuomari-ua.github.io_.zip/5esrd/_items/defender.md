---
category: items
layout: page
name: Defender
tag: weapon
title: Defender 
---
_Weapon (any sword), legendary (requires attunement)_ 

You gain a +3 bonus to attack and damage rolls made with this magic weapon.

The first time you attack with the sword on each of your turns, you can transfer some or all of the sword's bonus to your Armor Class, instead of using the bonus on any attacks that turn. For example, you could reduce the bonus to your attack and damage rolls to +1 and gain a +2 bonus to AC. The adjusted bonuses remain in effect until the start of your next turn, although you must hold the sword to gain a bonus to AC from it. 