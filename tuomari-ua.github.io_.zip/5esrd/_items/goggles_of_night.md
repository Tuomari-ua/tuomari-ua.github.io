---
category: items
layout: page
name: Goggles of Night
tag: item
title: Goggles of Night 
---
_Wondrous item, uncommon_ 

While wearing these dark lenses, you have darkvision out to a range of 60 feet. If you already have darkvision, wearing the goggles increases its range by 60 feet.