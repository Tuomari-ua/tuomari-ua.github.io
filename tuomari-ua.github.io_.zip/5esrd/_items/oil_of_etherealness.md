---
category: items
layout: page
name: Oil of Etherealness
tag: potion
title: Oil of Etherealness 
---
_Potion, rare_ 

Beads of this cloudy gray oil form on the outside of its container and quickly evaporate. The oil can cover a Medium or smaller creature, along with the equipment it's wearing and carrying (one additional vial is required for each size category above Medium). Applying the oil takes 10 minutes. The affected creature then gains the effect of the **_etherealness_** spell for 1 hour. 