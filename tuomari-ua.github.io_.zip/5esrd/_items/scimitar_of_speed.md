---
category: items
layout: page
name: Scimitar of Speed
tag: weapon
title: Scimitar of Speed 
---
_Weapon (scimitar), very rare (requires attunement)_ 

You gain a +2 bonus to attack and damage rolls made with this magic weapon. In addition, you can make one attack with it as a bonus action on each of your turns. 