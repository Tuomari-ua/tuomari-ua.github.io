---
category: items
layout: page
name: Helm of Telepathy
tag: item
title: Helm of Telepathy 
---
_Wondrous item, uncommon (requires attunement)_ 

While wearing this helm, you can use an action to cast the **_detect thoughts_** spell (save DC 13) from it. As long as you maintain concentration on the spell, you can use a bonus action to send a telepathic message to a creature you are focused on. It can reply--using a bonus action to do so--while your focus on it continues.

While focusing on a creature with **_detect thoughts_**, you can use an action to cast the **_suggestion_** spell (save DC 13) from the helm on that creature. Once used, the **_suggestion_** property can't be used again until the next dawn. 