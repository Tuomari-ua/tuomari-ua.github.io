---
category: items
layout: page
name: Necklace of Adaption
tag: item
title: Necklace of Adaptation 
---
_Wondrous item, uncommon (requires attunement)_ 

While wearing this necklace, you can breathe normally in any environment, and you have advantage on saving throws made against harmful gases and vapors (such as **_cloudkill_** and **_stinking cloud_** effects, inhaled poisons, and the breath weapons of some dragons). 